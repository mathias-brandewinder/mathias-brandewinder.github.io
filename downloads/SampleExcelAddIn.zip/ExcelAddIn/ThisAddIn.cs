﻿using Excel = Microsoft.Office.Interop.Excel;

namespace ExcelAddIn
{
    public partial class ThisAddIn
    {
        #region members

        private MenuManager m_MenuManager;

        #endregion

        private void ThisAddIn_Startup(object sender, System.EventArgs e)
        {
            #region VSTO generated code

            this.Application = (Excel.Application)Microsoft.Office.Tools.Excel.ExcelLocale1033Proxy.Wrap(typeof(Excel.Application), this.Application);

            #endregion

            m_MenuManager = new MenuManager(this);

            m_MenuManager.CreateAddInMenu("My Add-In");
            m_MenuManager.AddMenuItem("Do This");
            m_MenuManager.AddMenuItem("Do That");
        }

        private void ThisAddIn_Shutdown(object sender, System.EventArgs e)
        {
            m_MenuManager.UnsubscribeAll();
        }

        #region VSTO generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InternalStartup()
        {
            this.Startup += new System.EventHandler(ThisAddIn_Startup);
            this.Shutdown += new System.EventHandler(ThisAddIn_Shutdown);
        }

        #endregion
    }
}
