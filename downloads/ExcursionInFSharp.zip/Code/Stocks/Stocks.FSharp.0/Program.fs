﻿open System
open System.IO
open System.Net
open System.Text

let Main =
   Console.WriteLine("Welcome")

   Console.WriteLine("Enter Stock Symbol")
   let symbol = Console.ReadLine()

   Console.WriteLine("Enter start date (yyyy/mm/dd)")
   let startDate = DateTime.Parse(Console.ReadLine())

   Console.WriteLine("Enter end date (yyyy/mm/dd)")
   let endDate = DateTime.Parse(Console.ReadLine())

   let query = String.Format("&a={0}&b={1}&c={2}&d={3}&e={4}&f={5}&g=d&ignore=.csv", startDate.Month - 1, startDate.Day, startDate.Year, endDate.Month - 1, endDate.Day, endDate.Year)

   let url = "http://ichart.finance.yahoo.com/table.csv?s=" + symbol + query
   let request = WebRequest.Create(url)
   use response = request.GetResponse()
   use reader = new StreamReader(response.GetResponseStream(), Encoding.ASCII)
   let result = reader.ReadToEnd()
  
   Console.WriteLine(result)
   Console.ReadLine()

// extract function
// note return type of Main