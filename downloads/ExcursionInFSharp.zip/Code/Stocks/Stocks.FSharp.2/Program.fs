﻿open System
open System.Collections.Generic
open System.IO
open System.Linq
open System.Net
open System.Text

let baseUrl = "http://ichart.finance.yahoo.com/table.csv?s="

let fetch (startDate:DateTime) (endDate:DateTime) symbol =
   let query = String.Format("&a={0}&b={1}&c={2}&d={3}&e={4}&f={5}&g=d&ignore=.csv", startDate.Month - 1, startDate.Day, startDate.Year, endDate.Month - 1, endDate.Day, endDate.Year)
   let url = baseUrl + symbol + query
   let request = WebRequest.Create(url)
   use response = request.GetResponse()
   use reader = new StreamReader(response.GetResponseStream(), Encoding.ASCII)
   reader.ReadToEnd()

let cleanup (result:string) = 
   let lines = result.Split((char)10)
   [
      for i in 1 .. lines.Length - 1 do
         yield lines.[i]
   ] 
   |> List.rev 

type Quote = 
   { 
      Symbol:string;
      Date:DateTime;
      Open:float;
      Close:float;
      Low:float;
      High:float;
      Volume:Int64
   }

let Main =
   Console.WriteLine("Welcome")

   Console.WriteLine("Enter Stock Symbol")
   let symbol = Console.ReadLine()

   Console.WriteLine("Enter start date (yyyy/mm/dd)")
   let startDate = DateTime.Parse(Console.ReadLine())

   Console.WriteLine("Enter end date (yyyy/mm/dd)")
   let endDate = DateTime.Parse(Console.ReadLine())

   let result = fetch startDate endDate symbol
   let lines = cleanup result
   let parse (line:string) = 
      let q = line.Split(',')
      match q with
      | [| d;o;h;l;c;v;_|] -> 
         let quote = 
            { 
               Symbol = symbol;
               Date = DateTime.Parse(d);
               Open = Double.Parse(o);
               High = Double.Parse(h);
               Low = Double.Parse(l);
               Close = Double.Parse(c);
               Volume = Int64.Parse(v)
            }
         Some(quote)
      | _ -> None

   let quotes = List.choose (fun q -> q) <| List.map parse lines 

   let percentChange quote = (quote.Close - quote.Open) / quote.Open

   let averageIncrease = List.averageBy (fun it -> percentChange it) quotes
   let maxIncrease = List.map (fun it -> percentChange it) quotes |> List.max
   let maxDecrease = List.maxBy (fun it -> -(percentChange it)) quotes |> percentChange

   Console.WriteLine("Avg {0}, Min {1}, Max {2}", averageIncrease, maxIncrease, maxDecrease)

   let waitToClose = Console.ReadLine()
   ()