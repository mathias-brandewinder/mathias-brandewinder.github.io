﻿namespace Stocks.CSharp
{
   using System;
   using System.Collections.Generic;
   using System.IO;
   using System.Linq;
   using System.Net;
   using System.Text;

   class Program
   {
      static void Main(string[] args)
      {
         Console.WriteLine("Welcome");

         Console.WriteLine("Enter Stock Symbol");
         var symbol = Console.ReadLine();

         Console.WriteLine("Enter start date (yyyy/mm/dd)");
         var startDate = DateTime.Parse(Console.ReadLine());

         Console.WriteLine("Enter end date (yyyy/mm/dd)");
         var endDate = DateTime.Parse(Console.ReadLine());
         
         var query = String.Format(
            "&a={0}&b={1}&c={2}&d={3}&e={4}&f={5}&g=d&ignore=.csv",
            startDate.Month,
            startDate.Day,
            startDate.Year,
            endDate.Month,
            endDate.Day,
            endDate.Year);

         var quotes = ReadQuotes(symbol, query);

         var averageIncrease = quotes.Average(it => it.PercentChange);
         var maxIncrease = quotes.Max(it => it.PercentChange);
         var maxDecrease = quotes.Max(it => -it.PercentChange);

         Console.WriteLine("{0}: Avg {1:P} Best {2:P} Worst {3:P}", symbol, averageIncrease, maxIncrease, maxDecrease);
         Console.ReadLine();
      }

      public static IEnumerable<Quote> ReadQuotes(string symbol, string query)
      {
         var url = "http://ichart.finance.yahoo.com/table.csv?s=" + symbol + query;
         var quotes = new List<Quote>();
         var request = WebRequest.Create(url);
         using (var response = request.GetResponse())
         {
            using (var reader = new StreamReader(response.GetResponseStream(), Encoding.ASCII))
            {
               var result = reader.ReadToEnd();
               var lines = result.Split((char)10);
               foreach (var line in lines)
               {
                  if (!string.IsNullOrWhiteSpace(line))
                  {
                     var parsed = line.Split(',');

                     try
                     {
                        var quote = new Quote()
                                       {
                                          Symbol = symbol,
                                          Date = DateTime.Parse(parsed[0]),
                                          Open = Convert.ToDouble(parsed[1]),
                                          Close = Convert.ToDouble(parsed[4]),
                                          Low = Convert.ToDouble(parsed[3]),
                                          High = Convert.ToDouble(parsed[2]),
                                          Volume = Convert.ToInt64(parsed[5])
                                       };

                        quotes.Add(quote);
                     }
                     catch (Exception)
                     {
                        // swallowing the exception
                     }
                  }
               }

               return quotes;
            }
         }
      }
   }
}
