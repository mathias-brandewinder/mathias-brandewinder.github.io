﻿namespace CSharp.ConsoleClient
{
   using System;
   using System.Diagnostics;
   using FSharp.StocksReader;

   class Program
   {
      static void Main(string[] args)
      {
         var reader = new Reader();
         var greeting = reader.SayHello("Ben");
         Console.WriteLine(greeting);

         var urls = new string[]
                       {
                          "http://www.hanselman.com/blog/", 
                          "http://www.microsoft.com/net", 
                          "http://www.stackoverflow.com", 
                          "http://www.baynetug.org",
                          "http://www.slashdot.org",
                          "http://www.codinghorror.com/blog/"
                       };

         var timer = new Stopwatch();

         timer.Start();
         var syncResult = reader.ReadQuotes(false, urls);
         Console.WriteLine("Synchronous took " + timer.ElapsedMilliseconds);

         timer.Reset();

         timer.Start();
         var asyncResult = reader.ReadQuotes(true, urls);
         Console.WriteLine("Asynchronous took " + timer.ElapsedMilliseconds);

         Console.ReadLine();
      }
   }
}
