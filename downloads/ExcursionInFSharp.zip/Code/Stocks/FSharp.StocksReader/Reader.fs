﻿namespace FSharp.StocksReader

open System
open System.Collections.Generic
open System.IO
open System.Linq
open System.Net
open System.Text
open Microsoft.FSharp.Control.WebExtensions

type public Reader() =
   
   let sayHello (name:string) =
      "Hello, " + name

   let syncRead(url:string) =
      let request = WebRequest.Create(url)
      use response = request.GetResponse()
      use reader = new StreamReader(response.GetResponseStream(), Encoding.ASCII)
      reader.ReadToEnd()

   let asyncRead(url:string) =
      async {
         let request = WebRequest.Create(url)
         let! response = request.AsyncGetResponse()
         use stream = response.GetResponseStream()
         use reader = new StreamReader(stream, Encoding.ASCII)
         return! reader.AsyncReadToEnd()
      }

   member this.SayHello (name:string) =
      sayHello name

   member this.ReadQuotes (async:bool) (urls:string[]) =
      match async with
      | true -> Array.map asyncRead urls |> Async.Parallel |> Async.RunSynchronously
      | false -> Array.map syncRead urls