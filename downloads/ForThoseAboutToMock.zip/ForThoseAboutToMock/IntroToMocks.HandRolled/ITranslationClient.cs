﻿namespace IntroToMocks.HandRolled
{
   public interface ITranslationClient
   {
      string EnglishToFrench(string original);
   }
}
