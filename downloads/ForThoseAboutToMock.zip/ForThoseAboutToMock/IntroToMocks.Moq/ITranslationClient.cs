﻿namespace IntroToMocks.Moq
{
   public interface ITranslationClient
   {
      string EnglishToFrench(string original);
   }
}
