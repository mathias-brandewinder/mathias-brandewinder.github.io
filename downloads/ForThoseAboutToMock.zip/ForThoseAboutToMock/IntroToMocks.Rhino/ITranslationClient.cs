﻿namespace IntroToMocks.Rhino
{
   public interface ITranslationClient
   {
      string EnglishToFrench(string original);
   }
}
