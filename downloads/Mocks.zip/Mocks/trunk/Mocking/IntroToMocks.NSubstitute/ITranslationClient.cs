﻿namespace IntroToMocks.NSubstitute
{
   public interface ITranslationClient
   {
      string EnglishToFrench(string original);
   }
}
