﻿using log4net;
using NSubstitute;
using NUnit.Framework;

namespace IntroToMocks.NSubstitute.Tests
{
   [TestFixture]
   public class TestsTranslator
   {
      [Test]
      public void TranslationShouldReturnResultFromClient()
      {
         var log = Substitute.For<ILog>();
         var client = Substitute.For<ITranslationClient>();

         var translator = new Translator(log, client);

         var original = "Hello";
         var expected = "Bonjour";

         client.EnglishToFrench(original).Returns(expected);

         Assert.AreEqual(expected, translator.EnglishToFrench(original));
      }

      [Test]
      public void TranslationShouldLogMessage()
      {
         var log = Substitute.For<ILog>();
         var client = Substitute.For<ITranslationClient>();

         var translator = new Translator(log, client);

         translator.EnglishToFrench("Hello");

         log.Received().Debug("Translating");
      }
   }
}
