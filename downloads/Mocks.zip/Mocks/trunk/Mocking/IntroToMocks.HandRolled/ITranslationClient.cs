﻿namespace IntroToMocks.Refactored
{
   public interface ITranslationClient
   {
      string EnglishToFrench(string original);
   }
}
