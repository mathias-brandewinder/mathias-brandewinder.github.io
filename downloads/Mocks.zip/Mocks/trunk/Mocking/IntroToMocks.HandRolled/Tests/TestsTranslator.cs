﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using IntroToMocks.Refactored;
using NUnit.Framework;

namespace IntroToMocks.HandRolled.Tests
{
   [TestFixture]
   public class TestsTranslator
   {
      [Test]
      public void WhenTranslatingOriginalShouldBePassedToClientAndReturnResult()
      {
         var log = new FakeLog();
         var client = new FakeClient();

         var translator = new Translator(log, client);

         var original = "Hello";
         var expected = "Bonjour";
         client.Setup(original, expected);

         Assert.AreEqual(expected, translator.EnglishToFrench(original));
      }

      [Test]
      public void WhenTranslatingMessageShouldBePassedToLog()
      {
         var log = new FakeLog();
         var client = new FakeClient();

         var translator = new Translator(log, client);

         translator.EnglishToFrench("Hello");

         Assert.IsTrue(log.LastCallWasDebug);
         Assert.IsTrue(log.LastMessage == "Translating");
      }
   }
}
