﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using IntroToMocks.Refactored;
using log4net;
using NUnit.Framework;
using Rhino.Mocks;

namespace IntroToMocks.Rhino.Tests
{
   [TestFixture]
   public class TestsTranslator
   {
      [Test]
      public void TranslationShouldReturnResultFromClient()
      {
         var log = MockRepository.GenerateStub<ILog>();
         var client = MockRepository.GenerateStub<ITranslationClient>();

         var translator = new Translator(log, client);

         var original = "Hello";
         var expected = "Bonjour";

         client.Stub(me => me.EnglishToFrench(original))
            .Return(expected);

         Assert.AreEqual(expected, translator.EnglishToFrench(original));
      }

      [Test]
      public void TranslationShouldLogMessage()
      {
         var log = MockRepository.GenerateMock<ILog>();
         var client = MockRepository.GenerateStub<ITranslationClient>();

         var translator = new Translator(log, client);

         translator.EnglishToFrench("Hello");

         log.AssertWasCalled(me => me.Debug("Translating"));
      }
   }
}
