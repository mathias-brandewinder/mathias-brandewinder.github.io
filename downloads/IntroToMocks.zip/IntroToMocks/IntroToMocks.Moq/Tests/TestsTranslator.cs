﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using IntroToMocks.Refactored;
using log4net;
using NUnit.Framework;
using Moq;

namespace IntroToMocks.Moq.Tests
{
   [TestFixture]
   public class TestsTranslator
   {
      [Test]
      public void TranslationShouldReturnResultFromClient()
      {
         var log = new Mock<ILog>();
         var client = new Mock<ITranslationClient>();

         var translator = new Translator(log.Object, client.Object);

         var original = "Hello";
         var expected = "Bonjour";

         client.Setup(me => me.EnglishToFrench(original))
            .Returns(expected);

         Assert.AreEqual(expected, translator.EnglishToFrench(original));
      }

      [Test]
      public void TranslationShouldLogMessage()
      {
         var log = new Mock<ILog>();
         var client = new Mock<ITranslationClient>();

         var translator = new Translator(log.Object, client.Object);

         translator.EnglishToFrench("Hello");

         log.Verify(me => me.Debug("Translating"));
      }
   }
}
