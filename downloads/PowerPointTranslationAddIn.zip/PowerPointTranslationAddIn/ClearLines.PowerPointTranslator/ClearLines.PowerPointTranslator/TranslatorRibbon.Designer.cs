﻿namespace ClearLines.PowerPointTranslator
{
   partial class TranslatorRibbon
   {
      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.IContainer components = null;

      /// <summary> 
      /// Clean up any resources being used.
      /// </summary>
      /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
      protected override void Dispose(bool disposing)
      {
         if (disposing && (components != null))
         {
            components.Dispose();
         }
         base.Dispose(disposing);
      }

      #region Component Designer generated code

      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.tab1 = new Microsoft.Office.Tools.Ribbon.RibbonTab();
         this.Translator = new Microsoft.Office.Tools.Ribbon.RibbonGroup();
         this.showTranslator = new Microsoft.Office.Tools.Ribbon.RibbonButton();
         this.tab1.SuspendLayout();
         this.Translator.SuspendLayout();
         this.SuspendLayout();
         // 
         // tab1
         // 
         this.tab1.ControlId.ControlIdType = Microsoft.Office.Tools.Ribbon.RibbonControlIdType.Office;
         this.tab1.ControlId.OfficeId = "TabReview";
         this.tab1.Groups.Add(this.Translator);
         this.tab1.Label = "TabReview";
         this.tab1.Name = "tab1";
         // 
         // Translator
         // 
         this.Translator.Items.Add(this.showTranslator);
         this.Translator.Label = "Translator";
         this.Translator.Name = "Translator";
         // 
         // showTranslator
         // 
         this.showTranslator.ControlSize = Microsoft.Office.Core.RibbonControlSize.RibbonControlSizeLarge;
         this.showTranslator.Label = "Show Translator";
         this.showTranslator.Name = "showTranslator";
         this.showTranslator.ShowImage = true;
         this.showTranslator.Click += new System.EventHandler<Microsoft.Office.Tools.Ribbon.RibbonControlEventArgs>(this.showTranslator_Click);
         // 
         // TranslatorRibbon
         // 
         this.Name = "TranslatorRibbon";
         this.RibbonType = "Microsoft.PowerPoint.Presentation";
         this.Tabs.Add(this.tab1);
         this.Load += new System.EventHandler<Microsoft.Office.Tools.Ribbon.RibbonUIEventArgs>(this.TranslatorRibbon_Load);
         this.tab1.ResumeLayout(false);
         this.tab1.PerformLayout();
         this.Translator.ResumeLayout(false);
         this.Translator.PerformLayout();
         this.ResumeLayout(false);

      }

      #endregion

      internal Microsoft.Office.Tools.Ribbon.RibbonTab tab1;
      internal Microsoft.Office.Tools.Ribbon.RibbonGroup Translator;
      internal Microsoft.Office.Tools.Ribbon.RibbonButton showTranslator;
   }

   partial class ThisRibbonCollection : Microsoft.Office.Tools.Ribbon.RibbonReadOnlyCollection
   {
      internal TranslatorRibbon TranslatorRibbon
      {
         get { return this.GetRibbon<TranslatorRibbon>(); }
      }
   }
}
