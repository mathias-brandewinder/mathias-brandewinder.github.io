﻿// <copyright file="SlideTranslator.cs" company="Clear Lines Consulting, LLC">
//   Copyright (c) Clear Lines Consulting, LLC. All rights reserved.
// </copyright>

namespace ClearLines.PowerPointTranslator
{
   using Google.API.Translate;
   using PowerPoint = Microsoft.Office.Interop.PowerPoint;

   public class SlideTranslator
   {
      public static void TranslateSlide(Language from, Language to)
      {
         var googleTranslator = new TranslateClient("http://www.clear-lines.com");

         var powerpoint = Globals.ThisAddIn.Application;
         var slide = (PowerPoint.Slide)powerpoint.ActiveWindow.View.Slide;

         foreach (PowerPoint.Shape shape in slide.Shapes)
         {
            if (shape.HasTextFrame == Microsoft.Office.Core.MsoTriState.msoTrue)
            {
               var textFrame = shape.TextFrame;
               var textRange = textFrame.TextRange;
               TranslateTextRange(textRange, googleTranslator, from, to);
            }
         }
      }

      public static void TranslateTextRange(
         PowerPoint.TextRange textRange, 
         TranslateClient translator, 
         Language from,
         Language to)
      {
         var paragraphs = textRange.Paragraphs(-1, -1);
         foreach (PowerPoint.TextRange paragraph in paragraphs)
         {
            var text = paragraph.Text;
            text = text.Replace("\r", "");
            paragraph.Text = translator.Translate(text, from, to);
         }
      }
   }
}
