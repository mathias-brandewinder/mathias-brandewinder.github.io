﻿// <copyright file="ThisAddIn.cs" company="Clear Lines Consulting, LLC">
//   Copyright (c) Clear Lines Consulting, LLC. All rights reserved.
// </copyright>

namespace ClearLines.PowerPointTranslator
{
   using System.Collections.Generic;
   using ClearLines.PowerPointTranslator.TaskPane;
   using Google.API.Translate;
   using Microsoft.Office.Tools;

   public partial class ThisAddIn
   {
      private CustomTaskPane taskPane;

      internal CustomTaskPane TaskPane
      {
         get
         {
            return this.taskPane;
         }
      }

      private void ThisAddIn_Startup(object sender, System.EventArgs e)
      {
         var taskPaneHost = new TaskPaneHost();
         var view = taskPaneHost.View;
         var supportedLanguages = new List<Language>()
                                     {
                                        Language.English, 
                                        Language.French, 
                                        Language.Spanish
                                     };

         var translatorViewModel = new TranslatorViewModel(supportedLanguages);
         taskPaneHost.View.DataContext = translatorViewModel;

         this.taskPane = this.CustomTaskPanes.Add(taskPaneHost, "Translator");
         this.taskPane.Visible = true;
      }

      private void ThisAddIn_Shutdown(object sender, System.EventArgs e)
      {
      }

      #region VSTO generated code

      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InternalStartup()
      {
         this.Startup += new System.EventHandler(ThisAddIn_Startup);
         this.Shutdown += new System.EventHandler(ThisAddIn_Shutdown);
      }

      #endregion
   }
}
