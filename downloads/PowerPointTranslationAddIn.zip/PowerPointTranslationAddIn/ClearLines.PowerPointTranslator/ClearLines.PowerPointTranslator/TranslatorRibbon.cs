﻿namespace ClearLines.PowerPointTranslator
{
   using Microsoft.Office.Tools.Ribbon;

   public partial class TranslatorRibbon : OfficeRibbon
   {
      public TranslatorRibbon()
      {
         InitializeComponent();
      }

      private void TranslatorRibbon_Load(object sender, RibbonUIEventArgs e)
      {

      }

      private void showTranslator_Click(object sender, RibbonControlEventArgs e)
      {
         Globals.ThisAddIn.TaskPane.Visible = true;
      }
   }
}
