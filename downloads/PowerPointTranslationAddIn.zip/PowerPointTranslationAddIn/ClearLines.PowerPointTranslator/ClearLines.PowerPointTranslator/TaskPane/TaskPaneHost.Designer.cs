﻿namespace ClearLines.PowerPointTranslator.TaskPane
{
    partial class TaskPaneHost
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.WpfControlHost = new System.Windows.Forms.Integration.ElementHost();
            this.TranslatorView = new ClearLines.PowerPointTranslator.TaskPane.TranslatorView();
            this.SuspendLayout();
            // 
            // WpfControlHost
            // 
            this.WpfControlHost.Dock = System.Windows.Forms.DockStyle.Fill;
            this.WpfControlHost.Location = new System.Drawing.Point(0, 0);
            this.WpfControlHost.Name = "WpfControlHost";
            this.WpfControlHost.Size = new System.Drawing.Size(150, 150);
            this.WpfControlHost.TabIndex = 0;
            this.WpfControlHost.Text = "elementHost1";
            this.WpfControlHost.Child = this.TranslatorView;
            // 
            // TaskPaneHost
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.WpfControlHost);
            this.Name = "TaskPaneHost";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Integration.ElementHost WpfControlHost;
        private TranslatorView TranslatorView;
    }
}
