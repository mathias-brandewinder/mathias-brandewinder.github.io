﻿// <copyright file="TranslatorViewModel.cs" company="Clear Lines Consulting, LLC">
//   Copyright (c) Clear Lines Consulting, LLC. All rights reserved.
// </copyright>

namespace ClearLines.PowerPointTranslator.TaskPane
{
   using System.Collections.ObjectModel;
   using MvvmFoundation.Wpf;
   using Google.API.Translate;
   using System.Collections.Generic;

   public class TranslatorViewModel : ObservableObject
   {
      private ObservableCollection<Language> fromLanguages;
      private ObservableCollection<Language> toLanguages;
      private Language selectedFromLanguage;
      private Language selectedToLanguage;
      private RelayCommand translate;

      public TranslatorViewModel(IList<Language> languages)
      {
         this.fromLanguages = new ObservableCollection<Language>();
         this.toLanguages = new ObservableCollection<Language>();

         foreach (var language in languages)
         {
            this.fromLanguages.Add(language);
            this.toLanguages.Add(language);
         }
      }

      public Language SelectedFromLanguage
      {
         get
         {
            return this.selectedFromLanguage;
         }
         set
         {
            if (this.selectedFromLanguage != value)
            {
               this.selectedFromLanguage = value;
               base.RaisePropertyChanged("SelectedFromLanguage");
            }
         }
      }

      public Language SelectedToLanguage
      {
         get
         {
            return this.selectedToLanguage;
         }
         set
         {
            if (this.selectedToLanguage != value)
            {
               this.selectedToLanguage = value;
               base.RaisePropertyChanged("SelectedToLanguage");
            }
         }
      }

      public ObservableCollection<Language> FromLanguages
      {
         get
         {
            return this.fromLanguages;
         }
      }

      public ObservableCollection<Language> ToLanguages
      {
         get
         {
            return this.toLanguages;
         }
      }

      public RelayCommand Translate
      {
         get
         {
            if (this.translate == null)
            {
               this.translate = new RelayCommand(TranslateExecute, CanTranslate);
            }

            return this.translate;
         }
      }

      private void TranslateExecute()
      {
         SlideTranslator.TranslateSlide(
            this.SelectedFromLanguage, 
            this.SelectedToLanguage);
      }

      private bool CanTranslate()
      {
         if (this.SelectedFromLanguage == null)
         {
            return false;
         }

         if (this.SelectedToLanguage == null)
         {
            return false;
         }

         if (this.SelectedFromLanguage == this.SelectedToLanguage)
         {
            return false;
         }

         return true;
      }
   }
}
