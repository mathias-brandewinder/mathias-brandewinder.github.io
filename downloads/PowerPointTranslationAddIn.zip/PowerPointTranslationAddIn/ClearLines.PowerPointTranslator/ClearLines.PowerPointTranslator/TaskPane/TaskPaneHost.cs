﻿namespace ClearLines.PowerPointTranslator.TaskPane
{
   using System.Windows.Forms;

   public partial class TaskPaneHost : UserControl
   {
      public TaskPaneHost()
      {
         InitializeComponent();
      }

      internal TranslatorView View
      {
         get
         {
            return this.TranslatorView;
         }
      }
   }
}
