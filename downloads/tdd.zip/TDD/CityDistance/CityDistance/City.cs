﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CityDistance
{
    public class City
    {
        # region Constructor

        public City()
        {
        }

        # endregion

        #region Members

        private string m_Name;
        private double m_XCoordinate;
        private double m_YCoordinate;
        
        #endregion

        #region Properties
        
        public string Name
        {
            get
            {
                return m_Name;
            }
            set
            {
                if (value.Length < 1)
                {
                    throw new ArgumentException("Invalid city name.");
                }
                m_Name = value;
            }
        }

        public double XCoordinate
        {
            get
            {
                return m_XCoordinate;
            }
            set
            {
                m_XCoordinate = value;
            }
        }

        public double YCoordinate
        {
            get
            {
                return m_YCoordinate;
            }
            set
            {
                m_YCoordinate = value;
            }
        } 

        #endregion

        # region Methods

        internal double DistanceTo(City otherCity)
        {
            double distance = 0d;
            distance += (XCoordinate - otherCity.XCoordinate) * (XCoordinate - otherCity.XCoordinate);
            distance += (YCoordinate - otherCity.YCoordinate) * (YCoordinate - otherCity.YCoordinate);
            return Math.Sqrt(distance);
        }

        # endregion
    }
}
