﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using Rhino.Mocks;
using CityDistance.Mock;

namespace CityDistance.Tests
{
    [TestFixture]
    public class MockIllustration
    {
        [Test]
        public void RepositoryShouldReturnACityIfItHasBeenCreated()
        {
            string cityName = "San Francisco";
            
            ICityStorage storage = MockRepository.GenerateStub<ICityStorage>();
            storage.Expect(x => x.Create(cityName));
            storage.Expect(x => x.Read(cityName)).Return(new City());

            CityRepository repository = new CityRepository();
            repository.CityStorage = storage;

            repository.Create(cityName);
            City city = repository.Read(cityName);
            Assert.IsNotNull(city);

            storage.VerifyAllExpectations();
        }
    }
}
