﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;

namespace CityDistance.Tests
{
    [TestFixture]
    public class TestsCity
    {
        [Test]
        public void NameShouldBeGettableAndSettable()
        {
            City city = new City();
            string expectedName = "San Francisco";
            city.Name = expectedName;
            Assert.AreEqual(expectedName, city.Name);
        }

        [Test]
        public void XCoordinateShouldBeGettableAndSettable()
        {
            City city = new City();
            double xCoordinate = 42.0;
            city.XCoordinate = xCoordinate;
            Assert.AreEqual(xCoordinate, city.XCoordinate);
        }

        [Test]
        public void YCoordinateShouldBeGettableAndSettable()
        {
            City city = new City();
            double yCoordinate = 42.0;
            city.YCoordinate = yCoordinate;
            Assert.AreEqual(yCoordinate, city.YCoordinate);
        }

        [Test]
        public void DistanceFromShouldReturnEuclideanDistance()
        {
            City sanFrancisco = new City();
            City sanJose = new City();
            City paloAlto = new City();

            sanFrancisco.XCoordinate = 0;
            sanFrancisco.YCoordinate = 0;

            sanJose.XCoordinate = 1;
            sanJose.YCoordinate = 0;

            paloAlto.XCoordinate = 0;
            paloAlto.YCoordinate = 2;

            Assert.AreEqual(1, sanFrancisco.DistanceTo(sanJose));
            Assert.AreEqual(2, sanFrancisco.DistanceTo(paloAlto));
        }

        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void NameShouldBeLongerThanZero()
        {
            City city = new City();
            string badName = "";
            city.Name = badName;
        }
    }
}
