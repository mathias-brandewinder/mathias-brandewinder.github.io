﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;

namespace CityDistance.Tests
{
    [TestFixture]
    public class SetupIllustration
    {
        internal City City
        {
            get;
            set;
        }

        [SetUp]
        public void Setup()
        {
            City = new City();
            City.Name = "San Francisco";
        }

        [Test]
        public void NameIsSetBySetup()
        {
            Assert.AreEqual("San Francisco", City.Name);
        }
    }
}
