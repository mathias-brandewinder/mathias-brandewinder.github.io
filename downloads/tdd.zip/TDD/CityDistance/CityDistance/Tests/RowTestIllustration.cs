﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using NUnit.Framework.Extensions;

namespace CityDistance.Tests
{
    [TestFixture]
    public class RowTestIllustration
    {
        [RowTest]
        [Row(0d, 0d, 0d)]
        [Row(0d, 1d, 1d)]
        [Row(1d, 0d, 1d)]
        [Row(3d, 4d, 5d)]
        public void DistanceFromShouldReturnEuclideanDistance(double xCoordinate, double yCoordinate, double expectedDistance)
        {
            City city = new City();
            City otherCity = new City();

            city.XCoordinate = 0;
            city.YCoordinate = 0;

            otherCity.XCoordinate = xCoordinate;
            otherCity.YCoordinate = yCoordinate;

            Assert.AreEqual(expectedDistance, city.DistanceTo(otherCity));
        }
    }
}
