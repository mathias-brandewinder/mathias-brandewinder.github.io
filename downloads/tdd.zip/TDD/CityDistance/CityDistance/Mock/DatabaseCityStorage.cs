﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CityDistance.Mock
{
    public class DatabaseCityStorage:ICityStorage
    {
        // Lots of code goes here to access the database

        public City Read(string name)
        {
            return null;
        }

        public void Create(string name)
        {
        }
    }
}
