﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CityDistance.Mock
{
    public class CityRepository
    {
        internal ICityStorage CityStorage
        {
            get;
            set;
        }

        public City Read(string name)
        {
            return CityStorage.Read(name);
        }

        public void Create(string name)
        {
            CityStorage.Create(name);
        }
    }
}
