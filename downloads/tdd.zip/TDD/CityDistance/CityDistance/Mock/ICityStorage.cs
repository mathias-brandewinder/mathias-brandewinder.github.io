﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CityDistance.Mock
{
    public interface ICityStorage
    {
        City Read(string name);
        void Create(string name);
    }
}
