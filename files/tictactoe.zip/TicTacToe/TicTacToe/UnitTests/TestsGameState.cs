﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;

namespace TicTacToe.UnitTests
{
    [TestFixture]
    public class TestsGameState
    {
        [Test]
        public void NewGameStateShouldHaveEmptyStateForAll9Positions()
        {
            GameState gameState = new GameState();
            CellState expectedState = CellState.Empty;

            for (int row = 0; row < 3; row++)
            {
                for (int column = 0; column < 3; column++)
                {
                    Assert.AreEqual(expectedState, gameState.GetState(row, column));
                }
            }
        }

        [Test]
        public void CellsShouldBeSettable()
        {
            GameState gameState = new GameState();
            gameState.SetState(1, 1, CellState.O);
            Assert.AreEqual(CellState.O, gameState.GetState(1, 1));
        }

        [Test]
        [ExpectedException()]
        public void CellsWithRowsLargerThan2ShouldNotBeSettable()
        {
            GameState gameState = new GameState();
            gameState.SetState(3, 0, CellState.O);
        }

        [Test]
        [ExpectedException()]
        public void CellsWithColumnsLargerThan2ShouldNotBeSettable()
        {
            GameState gameState = new GameState();
            gameState.SetState(0, 3, CellState.O);
        }

        [Test]
        public void VerifyRowIsComplete()
        {
            GameState gameState = new GameState();
            CellState state = CellState.X;

            gameState.SetState(1, 0, state);
            gameState.SetState(1, 1, state);
            gameState.SetState(1, 2, state);
            Assert.IsTrue(gameState.RowIsComplete(1, state));

            gameState.SetState(1, 1, CellState.O);
            Assert.IsFalse(gameState.RowIsComplete(1, state));
        }

        [Test]
        public void VerifyColumnIsComplete()
        {
            GameState gameState = new GameState();
            CellState state = CellState.X;

            gameState.SetState(0, 2, state);
            gameState.SetState(1, 2, state);
            gameState.SetState(2, 2, state);
            Assert.IsTrue(gameState.ColumnIsComplete(2, state));

            gameState.SetState(1, 2, CellState.O);
            Assert.IsFalse(gameState.ColumnIsComplete(2, state));
        }

        [Test]
        public void VerifyUpDiagonalIsComplete()
        {
            GameState gameState = new GameState();
            CellState state = CellState.X;

            gameState.SetState(0, 0, state);
            gameState.SetState(1, 1, state);
            gameState.SetState(2, 2, state);
            Assert.IsTrue(gameState.UpDiagonalIsComplete(state));

            gameState.SetState(1, 1, CellState.O);
            Assert.IsFalse(gameState.UpDiagonalIsComplete(state));
        }

        [Test]
        public void VerifyDownDiagonalIsComplete()
        {
            GameState gameState = new GameState();
            CellState state = CellState.X;

            gameState.SetState(0, 2, state);
            gameState.SetState(1, 1, state);
            gameState.SetState(2, 0, state);
            Assert.IsTrue(gameState.DownDiagonalIsComplete(state));

            gameState.SetState(1, 1, CellState.O);
            Assert.IsFalse(gameState.DownDiagonalIsComplete(state));
        }
    }
}
