﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;

namespace TicTacToe.UnitTests
{
    [TestFixture]
    public class TestsGame
    {
        [Test]
        public void FirstNextPlayShouldBeX()
        {
            Game game = new Game();
            Assert.AreEqual(CellState.X, game.NextPlay());
        }

        [Test]
        public void NextPlayShouldAlternate()
        {
            Game game = new Game();
            Assert.AreEqual(CellState.X, game.NextPlay());
            game.Play(0, 0);
            Assert.AreEqual(CellState.O, game.NextPlay());
            game.Play(1, 1);
            Assert.AreEqual(CellState.X, game.NextPlay());
        }

        [Test]
        [ExpectedException()]
        public void PlayingNonEmptyCellShouldBeRefused()
        {
            Game game = new Game();
            game.Play(0, 0);
            game.Play(0, 0);
        }

        [Test]
        public void GameShouldBeFilledAlternativelyWithXAndOs()
        {
            Game game = new Game();
            game.Play(0, 0);
            Assert.AreEqual(CellState.X, game.GetState(0, 0));
            game.Play(1, 1);
            Assert.AreEqual(CellState.O, game.GetState(1, 1));
        }
    }
}
