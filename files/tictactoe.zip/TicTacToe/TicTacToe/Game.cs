﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TicTacToe
{
    public class Game
    {
        #region Members

        private GameState m_GameState;
      
        #endregion

        #region Constructor

        public Game()
        {
            m_GameState = new GameState();
        }
       
        #endregion

        #region Methods

        public void Play(int row, int column)
        {
            if (GameState.GetState(row, column) != CellState.Empty)
            {
                throw new ArgumentException("That cell has already been played!");
            }
            CellState nextPlay = NextPlay();
            GameState.SetState(row, column, nextPlay);
        }

        public CellState GetState(int row, int column)
        {
            return GameState.GetState(row, column);
        }

        public bool HasWon(CellState playerSymbol)
        {
            for (int row = 0; row < 3; row++)
            {
                if (GameState.RowIsComplete(row, playerSymbol))
                {
                    return true;
                }
            }
            for (int column = 0; column < 3; column++)
            {
                if (GameState.ColumnIsComplete(column, playerSymbol))
                {
                    return true;
                }
            }
            if (GameState.DownDiagonalIsComplete(playerSymbol))
            {
                return true;
            }
            if (GameState.UpDiagonalIsComplete(playerSymbol))
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// Returns the next player (X or O)
        /// </summary>
        internal CellState NextPlay()
        {
            int count = 0;
            for (int row = 0; row < 3; row++)
            {
                for (int column = 0; column < 3; column++)
                {
                    if (GameState.GetState(row, column) != CellState.Empty)
                    {
                        count++;
                    }
                }
            }
            if ((count % 2) == 0)
            {
                return CellState.X;
            }
            else
            {
                return CellState.O;
            }
        }

        #endregion

        # region Properties

        internal GameState GameState
        {
            get
            {
                return m_GameState;
            }
        }

        # endregion
    }
}
