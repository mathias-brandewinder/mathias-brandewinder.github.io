﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TicTacToe
{
    internal class GameState
    {
        private Dictionary<int, Dictionary<int, CellState>> m_GameState;

        internal GameState()
        {
            m_GameState = new Dictionary<int, Dictionary<int, CellState>>();
            SetupInitialState();
        }

        internal void SetState(int row, int column, CellState state)
        {
            Dictionary<int, CellState> rowState = m_GameState[row];
            if (!rowState.ContainsKey(column))
            {
                throw new ArgumentOutOfRangeException();
            }
            rowState[column] = state;
        }

        internal CellState GetState(int row, int column)
        {
            Dictionary<int, CellState> rowState = m_GameState[row];
            return rowState[column];
        }

        internal void SetupInitialState()
        {
            Dictionary<int, Dictionary<int, CellState>> gameState = new Dictionary<int, Dictionary<int, CellState>>();
            for (int row = 0; row < 3; row++)
            {
                Dictionary<int, CellState> rowState = new Dictionary<int, CellState>();
                for (int column = 0; column < 3; column++)
                {
                    rowState.Add(column, CellState.Empty);
                }
                gameState.Add(row, rowState);
            }
            m_GameState = gameState;
        }

        internal bool RowIsComplete(int row, CellState symbol)
        {
            if (GetState(row, 0) == symbol && GetState(row, 1) == symbol && GetState(row, 2) == symbol)
            {
                return true;
            }
            return false;
        }

        internal bool ColumnIsComplete(int column, CellState symbol)
        {
            if (GetState(0, column) == symbol && GetState(1, column) == symbol && GetState(2, column) == symbol)
            {
                return true;
            }
            return false;
        }

        internal bool UpDiagonalIsComplete(CellState symbol)
        {
            if (GetState(0, 0) == symbol && GetState(1, 1) == symbol && GetState(2, 2) == symbol)
            {
                return true;
            }
            return false;
        }

        internal bool DownDiagonalIsComplete(CellState symbol)
        {
            if (GetState(0, 2) == symbol && GetState(1, 1) == symbol && GetState(2, 0) == symbol)
            {
                return true;
            }
            return false;
        }
    }
}
