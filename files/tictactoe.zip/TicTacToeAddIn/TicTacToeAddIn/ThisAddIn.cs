﻿using System.Windows.Forms;
using Microsoft.Office.Core;
using SwitchBoard;
using Excel = Microsoft.Office.Interop.Excel;
using TicTacToeAddIn.Operations;
using TicTacToe;

namespace TicTacToeAddIn
{
    public partial class ThisAddIn
    {
        #region Members

        private AddInMenu m_Menu;
        private OperationsManager m_OperationsManager;

        #endregion

        # region Properties

        internal OperationsManager Operations
        {
            get
            {
                return m_OperationsManager;
            }
        }

        internal Game Game
        {
            get;
            set;
        }

        # endregion

        private void ThisAddIn_Startup(object sender, System.EventArgs e)
        {
            #region VSTO generated code

            this.Application = (Excel.Application)Microsoft.Office.Tools.Excel.ExcelLocale1033Proxy.Wrap(typeof(Excel.Application), this.Application);

            #endregion

            # region Adding operations

            m_OperationsManager = new OperationsManager();

            StartNewGame startNewGame = new StartNewGame();
            startNewGame.AddIn = this;
            m_OperationsManager.AddOperation(startNewGame);

            UpdateGame updateGame = new UpdateGame();
            updateGame.AddIn = this;
            m_OperationsManager.AddOperation(updateGame);

            # endregion

            # region Creating the menu

            CommandBar menuBar = Application.CommandBars["Worksheet Menu Bar"];

            m_Menu = new AddInMenu(menuBar);
            m_Menu.Title = "TicTacToe";
            m_Menu.CreateAddInMenu();
            m_Menu.AddMenuItem("New Game", "StartNewGame");
            m_Menu.AddMenuItem("Enter Move", "UpdateGame");

            m_OperationsManager.RegisterControlManager(m_Menu);

            # endregion
        }

        private void ThisAddIn_Shutdown(object sender, System.EventArgs e)
        {
            m_OperationsManager.UnregisterControlManager();
            m_Menu.UnsubscribeAll();
        }

        #region VSTO generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InternalStartup()
        {
            this.Startup += new System.EventHandler(ThisAddIn_Startup);
            this.Shutdown += new System.EventHandler(ThisAddIn_Shutdown);
        }
        
        #endregion
    }
}
