﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Microsoft.Office.Core;
using Office = Microsoft.Office.Core;

namespace SwitchBoard
{
    /// <summary>
    /// The MenuManager is responsible for creating menu items
    /// for the add-in, and for handling the corresponding click events.
    /// It currently assumes that the add-in will use only one
    /// menu with multiple menu items.
    /// </summary>
    internal class AddInMenu
    {
        #region Members

        private CommandBar m_HostMenuBar;
        private CommandBarControl m_AddInMenu;
        private List<CommandBarButton> m_MenuItems;
        private Dictionary<int, string> m_MenuOperationAssociation;

        public event OperationRequestedEventHandler OperationRequested;
 
        #endregion

        #region Constructor

        internal AddInMenu(CommandBar commandBar)
        {
            m_HostMenuBar = commandBar;
            m_MenuItems = new List<CommandBarButton>();
            m_MenuOperationAssociation = new Dictionary<int, string>();           
        }

        #endregion

        public string Title
        {
            get;
            set;
        }

        internal void CreateAddInMenu()
        {
            try
            {
                CommandBarControl menu = m_HostMenuBar.Controls.Add(
                    MsoControlType.msoControlPopup,
                    Type.Missing, Type.Missing, Type.Missing, true);
                menu.Caption = Title;
                m_AddInMenu = menu;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        internal void AddMenuItem(string menuItemCaption, string addInOperationName)
        {
            CommandBarButton menuItem = CreateMenuItem((CommandBarPopup)m_AddInMenu, menuItemCaption);
            m_MenuItems.Add(menuItem);
            m_MenuOperationAssociation.Add(menuItem.InstanceId, addInOperationName);
            SubscribeMenuItemClick(menuItem);
        }

        #region helper methods

        private CommandBarButton CreateMenuItem(CommandBarPopup parentMenu, string menuItemCaption)
        {
            CommandBarControl commandBarControl = null;
            try
            {
                commandBarControl = parentMenu.Controls.Add(
                    MsoControlType.msoControlButton, Type.Missing,
                    Type.Missing, Type.Missing, true);
                commandBarControl.Caption = menuItemCaption;
                commandBarControl.Visible = true;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message,
                    ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return (CommandBarButton)commandBarControl;
        }
        
        #endregion

        #region handling of events

        /// <summary>
        /// Handles the Click event for add-in menu items.
        /// </summary>
        /// <param name="Ctrl">A menu item of the add-in menu.</param>
        /// <param name="CancelDefault"></param>
        private void MenuItem_Click(CommandBarButton menuItem, ref Boolean CancelDefault)
        {
            ExecuteMenuItemAction(menuItem);
        }

        private void ExecuteMenuItemAction(CommandBarButton menuItem)
        {
            string operation = m_MenuOperationAssociation[menuItem.InstanceId];
            OperationRequestedEventArgs args = new OperationRequestedEventArgs(operation);
            OnOperationRequested(menuItem, args);
        }

        private void SubscribeMenuItemClick(CommandBarButton menuItem)
        {
            menuItem.Click += new _CommandBarButtonEvents_ClickEventHandler(MenuItem_Click);
        }

        private void UnsubscribeMenuItemClick(Office.CommandBarButton menuItem)
        {
            menuItem.Click -= new _CommandBarButtonEvents_ClickEventHandler(MenuItem_Click);
        }

        internal void UnsubscribeAll()
        {
            foreach (CommandBarButton menuItem in m_MenuItems)
            {
                UnsubscribeMenuItemClick(menuItem);
            }
        }

        protected virtual void OnOperationRequested(object origin, OperationRequestedEventArgs e)
        {
            if (OperationRequested != null)
            {
                OperationRequested(origin, e);
            }
        }

        #endregion
    }
}