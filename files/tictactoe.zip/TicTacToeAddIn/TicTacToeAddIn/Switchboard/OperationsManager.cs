﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using Microsoft.Office.Interop.Excel;

namespace SwitchBoard
{
    public delegate void OperationRequestedEventHandler(object sender, OperationRequestedEventArgs e);

    internal class OperationsManager
    {
        private AddInMenu m_Menu;
        private List<IAddInOperation> m_SupportedOperations;

        internal OperationsManager()
        {
            m_SupportedOperations = new List<IAddInOperation>();
            
        }

        internal void AddOperation(IAddInOperation service)
        {
            m_SupportedOperations.Add(service);
        }

        internal void RegisterControlManager(AddInMenu manager)
        {
            m_Menu = manager;
            manager.OperationRequested += new OperationRequestedEventHandler(OperationRequested);
        }

        internal void UnregisterControlManager()
        {
            if (m_Menu != null)
            {
                m_Menu.OperationRequested -= new OperationRequestedEventHandler(OperationRequested);
                m_Menu = null;
            }
        }

        internal bool RunOperation(string selectedOperation)
        {
            bool operationFound = false;
            foreach (IAddInOperation process in m_SupportedOperations)
            {
                if (selectedOperation == process.Name)
                {
                    bool operationSuccess = process.Run();
                    operationFound = true;
                    return operationSuccess;
                }
            }
            if (!operationFound)
            {
                MessageBox.Show("Operation not supported", "Add-In Operation Manager", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }
            return false;
        }

        private void OperationRequested(object sender, OperationRequestedEventArgs e)
        {
            string selectedOperation = e.RequestedOperation;
            RunOperation(selectedOperation);
        }
    }
}
