﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SwitchBoard
{
    public interface IAddInOperation
    {
        string Name
        {
            get;
        }
        bool Run();
    }
}
