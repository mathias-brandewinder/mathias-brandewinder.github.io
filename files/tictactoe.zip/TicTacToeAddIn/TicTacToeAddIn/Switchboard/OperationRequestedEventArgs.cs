﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SwitchBoard
{
    /// <summary>
    /// OperationRequestedEventArgs conveys that an operation
    /// has been requested. RequestedOperation must be a valid
    /// operation listed in the OperationsManager.
    /// </summary>
    public class OperationRequestedEventArgs: EventArgs
    {
        private string m_RequestedOperation;
        public string RequestedOperation
        {
            get
            {
                return m_RequestedOperation;
            }
            set
            {
                m_RequestedOperation = value;
            }
        }
        internal OperationRequestedEventArgs(string requestedOperation)
        {
            m_RequestedOperation = requestedOperation;
        }
    }
}
