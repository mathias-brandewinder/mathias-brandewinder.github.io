﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TicTacToe;

namespace TicTacToeAddIn.Utilities
{
    public class CellStateConverter
    {
        public string CellStateToString(CellState state)
        {
            switch (state)
            {
                case CellState.X:
                    return "X";
                case CellState.O:
                    return "O";
                case CellState.Empty:
                    return "";
                default:
                    throw new NotSupportedException();
            }
        }

        public CellState StringToCellState(string name)
        {
            string capitalizedName = name.ToUpper();
            switch (capitalizedName)
            {
                case "X":
                    return CellState.X;
                case "O":
                    return CellState.O;
                default:
                    return CellState.Empty;
            }
        }
    }
}
