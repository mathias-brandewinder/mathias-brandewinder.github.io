﻿using System.Reflection;
using SwitchBoard;
using TicTacToe;
using TicTacToeAddIn.Utilities;
using Excel = Microsoft.Office.Interop.Excel;

namespace TicTacToeAddIn.Operations
{
    internal class WriteGameState:IAddInOperation
    {
        internal ThisAddIn AddIn
        {
            get;
            set;
        }

        #region IAddInOperation

        public string Name
        {
            get 
            {
                return "WriteGameState";
            }
        }

        public bool Run()
        {
            Excel.Workbook activeWorkbook = AddIn.Application.ActiveWorkbook;
            Excel.Worksheet activeWorksheet = (Excel.Worksheet)activeWorkbook.ActiveSheet;
            Excel.Range ticTacToeRange = activeWorksheet.get_Range("TicTacToe", Missing.Value);

            object[,] gameState = new object[3, 3];
            Game game = AddIn.Game;
            CellStateConverter converter = new CellStateConverter();
            for (int row = 0; row < 3; row++)
            {
                for (int column = 0; column < 3; column++)
                {
                    CellState state = game.GetState(row, column);
                    string stateName = converter.CellStateToString(state);
                    gameState[row, column] = stateName;
                }
            }

            ticTacToeRange.Value2 = gameState;

            return true;
        }

        #endregion
    }
}
