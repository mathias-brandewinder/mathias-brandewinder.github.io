﻿using System.Windows.Forms;
using SwitchBoard;
using TicTacToe;

namespace TicTacToeAddIn.Operations
{
    public class StartNewGame:IAddInOperation
    {
        internal ThisAddIn AddIn
        {
            get;
            set;
        }

        #region IAddInOperation

        public string Name
        {
            get 
            {
                return "StartNewGame";
            }
        }

        public bool Run()
        {
            MessageBox.Show("Starting a new game");
            AddIn.Game = new Game();

            WriteGameState writeState = new WriteGameState();
            writeState.AddIn = this.AddIn;
            writeState.Run();

            return true;
        }

        #endregion
    }
}
