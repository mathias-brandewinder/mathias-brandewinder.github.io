﻿using System.Reflection;
using SwitchBoard;
using TicTacToe;
using Excel = Microsoft.Office.Interop.Excel;
using TicTacToeAddIn.Utilities;
using System.Windows.Forms;
using System;

namespace TicTacToeAddIn.Operations
{
    public class UpdateGame:IAddInOperation
    {
        internal ThisAddIn AddIn
        {
            get;
            set;
        }

        #region IAddInOperation Members

        public string Name
        {
            get
            {
                return "UpdateGame";
            }
        }

        public bool Run()
        {
            Game game = AddIn.Game;
            if (game.HasWon(CellState.X) || game.HasWon(CellState.O))
            {
                MessageBox.Show("This game already has a winner. If you want to play, start a new game.");
                return true;
            }
            
            Excel.Workbook activeWorkbook = AddIn.Application.ActiveWorkbook;
            Excel.Worksheet activeWorksheet = (Excel.Worksheet)activeWorkbook.ActiveSheet;
            Excel.Range ticTacToeRange = activeWorksheet.get_Range("TicTacToe", Missing.Value);

            CellState[,] gameState = ReadGameStateFromWorksheet(ticTacToeRange);

            int playRow = -1;
            int playColumn = -1;
            int countDifferences = 0;
            for (int row = 0; row < 3; row++)
            {
                for (int column = 0; column < 3; column++)
                {
                    if (gameState[row, column] != game.GetState(row, column))
                    {
                        playRow = row;
                        playColumn = column;
                        countDifferences++;
                    }
                }
            }
            if (countDifferences == 0)
            {
                MessageBox.Show("Could not find a difference. Please enter a move.");
            }
            else if (countDifferences > 1)
            {
                MessageBox.Show("More than one difference has been found. Please enter a valid move.");
            }
            else
            {
                game.Play(playRow, playColumn);

                if (game.HasWon(CellState.X))
                {
                    MessageBox.Show("You won!");
                }
                else
                {
                    PlayComputerMove(game);

                    if (game.HasWon(CellState.O))
                    {
                        MessageBox.Show("The computer won!");
                    }
                }
            }

            WriteGameState writeState = new WriteGameState();
            writeState.AddIn = this.AddIn;
            writeState.Run();

            return true;
        }

        #endregion

        # region Helper methods

        private CellState[,] ReadGameStateFromWorksheet(Excel.Range ticTacToeRange)
        {
            CellState[,] gameState = new CellState[3, 3];
            CellStateConverter converter = new CellStateConverter();

            for (int row = 0; row < 3; row++)
            {
                for (int column = 0; column < 3; column++)
                {
                    Excel.Range cell = (Excel.Range)ticTacToeRange.Cells[row + 1, column + 1];
                    string cellContent = string.Empty;
                    if (cell.Value2 != null)
                    {
                        cellContent = cell.Value2.ToString();
                    }
                    CellState state = converter.StringToCellState(cellContent);
                    gameState[row, column] = state;
                }
            }
            return gameState;
        }

        private void PlayComputerMove(Game game)
        {
            Random randomizer = new Random();
            int computerRow;
            int computerColumn;
            do
            {
                computerRow = randomizer.Next(0, 3);
                computerColumn = randomizer.Next(0, 3);
            }
            while (game.GetState(computerRow, computerColumn) != CellState.Empty);
            game.Play(computerRow, computerColumn);
        }

        # endregion
    }
}
